(function(subject) {
  console.log("hello, " + subject);
})("world");
