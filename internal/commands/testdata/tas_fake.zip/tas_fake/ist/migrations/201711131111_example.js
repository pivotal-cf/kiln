exports.migrate = function(input) {
  var properties = input.properties;

  // perform your migration

  return input;
};
